#!/bin/bash

clear

chmod +x OWL.sh

echo "E/[31mI will now open the script."
echo "E/[97mTo do this later go into the directory of the script and type ./OWL.sh"

./OWL.sh
