   ██████████████ █████   █████   █████ ████
   ████      ████   ███    ███    ███   ████
   ████      ████   ███    ███    ███   ████
   ████      ████   ███    ███    ███   ████
   ████      ████   ███    ███    ███   ████
   ████      ████   ███    ███    ███   ████
   ████      ████   ███    ███    ███   ████ 
   ████      ████   ███    ███    ███   ████ 
   ████      ████    ██    ███    ██    ████
   ██████████████    ███████████████    ███████████ 


 This tool is made by binaryB4T.

                                 /|_M_|\
                                |       |  
     -                           \|^V^|/

===========INSTALL===========
To install:
[1] Open a terminal window from the OWL_MASTER directory.
[2] Run the command - ./INSTALLER.sh
[3] It will now automatically install.

====TO OPEN FROM TERMINAL====
To open:
[1] Open a terminal window from the OWL_Master directory.
[2] Run the command - ./OWL.sh


*I AM IN NO WAY RESPONSIBLE FOR WHAT EVER YOU DO. 
 EVERYTHING IS ON YOU!


